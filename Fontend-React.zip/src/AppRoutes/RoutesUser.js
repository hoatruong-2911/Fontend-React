import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import HomePage from "../pages/User/HomePage";
import ProductListPage from "../pages/User/products/ProductListPage";
import ProductDetailPage from "../pages/User/products/ProductDetailPage";
import CartPage from "../pages/User/cart/CartPage";
import CheckoutPage from "../pages/User/checkout/CheckoutPage";
import BlogPage from "../pages/User/blog/BlogPage";
import AboutPage from "../pages/User/about/AboutPage";
import ContactPage from "../pages/User/contact/ContactPage";
import LoginPage from "../pages/User/auth/LoginPage";
import RegisterPage from "../pages/User/auth/RegisterPage";

export default function RoutesUser() {
  return (
    <Routes>
      <Route index element={<HomePage />} />
      <Route path="products" element={<ProductListPage />} />
      <Route path="product/:id" element={<ProductDetailPage />} />
      <Route path="cart" element={<CartPage />} />
      <Route path="checkout" element={<CheckoutPage />} />
      <Route path="blog" element={<BlogPage />} />
      <Route path="about" element={<AboutPage />} />
      <Route path="contact" element={<ContactPage />} />
      <Route path="login" element={<LoginPage />} />
      <Route path="register" element={<RegisterPage />} />
      <Route path="*" element={<Navigate replace to="/user" />} />
    </Routes>
  );
}
