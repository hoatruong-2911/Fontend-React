import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import AdminLayout from "../layouts/AdminLayout";

import ProductListPage from "../pages/Admin/products/ProductListPage";
import AddProductPage   from "../pages/Admin/products/AddProductPage";
import EditProductPage  from "../pages/Admin/products/EditProductPage";

import CategoryListPage from "../pages/Admin/categorys/CategoryListPage";
import AddCategoryPage  from "../pages/Admin/categorys/AddCategoryPage";
import EditCategoryPage from "../pages/Admin/categorys/EditCategoryPage";

export default function RoutesAdmin() {
  return (
    <Routes>
      {/* CHỈ mount layout ở /admin */}
      <Route path="/admin" element={<AdminLayout />}>
        {/* trang mặc định */}
        <Route index element={<Navigate replace to="products" />} />

        {/* dùng ĐƯỜNG DẪN TƯƠNG ĐỐI (không có dấu / ở đầu) */}
        <Route path="products" element={<ProductListPage />} />
        <Route path="add-product" element={<AddProductPage />} />
        <Route path="edit-product/:id" element={<EditProductPage />} />

        <Route path="categories" element={<CategoryListPage />} />
        <Route path="add-category" element={<AddCategoryPage />} />
        <Route path="edit-category/:id" element={<EditCategoryPage />} />

        {/* fallback */}
        <Route path="*" element={<Navigate replace to="products" />} />
      </Route>
    </Routes>
  );
}
