// src/layouts/UserLayout.jsx
import React from "react";
import { Outlet, Link, useLocation } from "react-router-dom";

/**
 * UserLayout
 * - Giao diện người dùng (Header + Navbar + Mega menu + Footer)
 * - Đặt cùng cấp với: src/layouts/AdminLayout.jsx
 * - Dùng TailwindCSS, tương thích với hệ thống route /user/*
 */

export default function UserLayout() {
  const location = useLocation();
  const isActive = (path) =>
    location.pathname === path ? "text-emerald-700 font-bold" : "hover:text-emerald-700";

  return (
    <div className="min-h-screen flex flex-col bg-[#f8fafb] text-slate-900">
      {/* Topbar */}
      <div className="w-full bg-emerald-700 text-white text-sm">
        <div className="max-w-[1200px] mx-auto px-4 py-2 flex items-center justify-between">
          <div className="opacity-95">
            Hotline: <span className="font-semibold">1900 6750</span> · Ladeco Building, 266 Đội Cấn, Hà Nội
          </div>
          <div className="space-x-2">
            <Link to="/user/login" className="hover:underline">Đăng nhập</Link>
            <span className="opacity-60">hoặc</span>
            <Link to="/user/register" className="hover:underline">Đăng ký</Link>
          </div>
        </div>
      </div>

      {/* Navbar + Mega menu */}
      <header className="bg-white sticky top-0 z-40 border-b border-slate-200 shadow-sm">
        <div className="max-w-[1200px] mx-auto px-4 py-4 flex items-center gap-4">
          <Link to="/user" className="text-2xl font-black text-emerald-800">
            DuaLeo-X
          </Link>

          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <input
                className="w-full border border-slate-200 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-200"
                placeholder="Tìm sản phẩm, danh mục…"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">⌕</div>
            </div>
          </div>

          {/* Cart */}
          <Link
            to="/user/cart"
            className="inline-flex items-center gap-2 rounded-lg border border-emerald-600 bg-emerald-600 text-white px-4 py-2 font-semibold hover:opacity-95"
          >
            Giỏ hàng (0)
          </Link>
        </div>

        {/* Navigation menu */}
        <nav className="max-w-[1200px] mx-auto px-4 pb-3">
          <ul className="flex items-center gap-4 font-semibold text-slate-700">
            <li><Link to="/user" className={`px-2 py-1 rounded ${isActive("/user")}`}>Trang chủ</Link></li>

            {/* Mega menu */}
            <li className="relative group">
              <Link to="/user/products" className="px-2 py-1 rounded hover:bg-slate-100 inline-flex items-center gap-1">
                Sản phẩm <span className="opacity-60">▾</span>
              </Link>

              <div className="invisible opacity-0 group-hover:visible group-hover:opacity-100 transition
                              absolute left-0 top-full w-[900px] bg-white border border-slate-200 rounded-xl shadow-xl p-4">
                <div className="grid grid-cols-4 gap-6 text-sm">
                  {[
                    {
                      title: "Rau củ",
                      items: [
                        ["Rau tươi", "rau-tuoi"],
                        ["Rau vườn", "rau-vuon"],
                        ["Rau sạch", "rau-sach"],
                        ["Củ nhập khẩu", "cu-nhap-khau"],
                      ],
                    },
                    {
                      title: "Hoa quả",
                      items: [
                        ["Trái cây tươi", "trai-cay-tuoi"],
                        ["Hoa quả sạch", "hoa-qua-sach"],
                        ["Hoa quả nhập khẩu", "hoa-qua-nhap"],
                      ],
                    },
                    {
                      title: "Thịt",
                      items: [
                        ["Thịt gà", "thit-ga"],
                        ["Thịt lợn", "thit-lon"],
                        ["Thịt bò", "thit-bo"],
                        ["Thịt vịt", "thit-vit"],
                      ],
                    },
                    {
                      title: "Hải sản",
                      items: [
                        ["Ngao", "ngao"],
                        ["Sò huyết", "so-huyet"],
                        ["Cua", "cua"],
                        ["Tôm", "tom"],
                      ],
                    },
                  ].map((group) => (
                    <div key={group.title}>
                      <div className="font-bold text-slate-900 mb-2">{group.title}</div>
                      <ul className="space-y-1 text-slate-700">
                        {group.items.map(([label, cat]) => (
                          <li key={cat}>
                            <Link
                              to={`/user/products?cat=${cat}`}
                              className="hover:underline"
                            >
                              {label}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            </li>

            <li><Link to="/user/about" className={`px-2 py-1 rounded ${isActive("/user/about")}`}>Giới thiệu</Link></li>
            <li><Link to="/user/blog" className={`px-2 py-1 rounded ${isActive("/user/blog")}`}>Tin tức</Link></li>
            <li><Link to="/user/contact" className={`px-2 py-1 rounded ${isActive("/user/contact")}`}>Liên hệ</Link></li>
            <li><a href="https://maps.google.com" target="_blank" rel="noreferrer" className="px-2 py-1 rounded hover:bg-slate-100">Chỉ đường</a></li>
          </ul>
        </nav>
      </header>

      {/* Nội dung các trang con */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-200 mt-10">
        <div className="max-w-[1200px] mx-auto px-4 py-10 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <div className="text-white text-2xl font-black mb-2">DuaLeo-X</div>
            <p className="text-slate-400">
              Chúng tôi chuyên cung cấp các sản phẩm thực phẩm sạch, an toàn cho sức khỏe con người.
            </p>
            <p className="mt-3 text-slate-400">Ladeco Building, 266 Đội Cấn, Hà Nội — 1900 6750</p>
            <p className="text-slate-400">Thứ 2 - Chủ nhật: 9:00 - 18:00</p>
          </div>

          <div>
            <div className="font-bold text-white mb-2">Hỗ trợ</div>
            <ul className="space-y-1">
              <li><Link to="/user/contact" className="hover:underline">Liên hệ</Link></li>
              <li><Link to="/user/about" className="hover:underline">Về chúng tôi</Link></li>
            </ul>
          </div>

          <div>
            <div className="font-bold text-white mb-2">Danh mục</div>
            <ul className="space-y-1">
              <li><Link to="/user/products?cat=rau-sach" className="hover:underline">Rau sạch</Link></li>
              <li><Link to="/user/products?cat=hoa-qua" className="hover:underline">Hoa quả</Link></li>
              <li><Link to="/user/products?cat=thit" className="hover:underline">Thịt</Link></li>
              <li><Link to="/user/products?cat=hai-san" className="hover:underline">Hải sản</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 text-center py-3 text-slate-400 text-sm">
          © {new Date().getFullYear()} DuaLeo-X — All rights reserved.
        </div>
      </footer>
    </div>
  );
}
